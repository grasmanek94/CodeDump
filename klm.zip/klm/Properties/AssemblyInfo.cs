using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: AssemblyVersion("1.0.1112.1901")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Micro-Star International Co., Ltd.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2010 Micro-Star International Co., Ltd. All rights reserved.")]
[assembly: AssemblyDescription("Application to control keyboard LED module")]
[assembly: AssemblyFileVersion("1.0.1112.1901")]
[assembly: AssemblyProduct("MSI Keyboard LED Manager")]
[assembly: AssemblyTitle("MSI Keyboard LED Manager")]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
[assembly: Guid("4DEA5B85-6C56-45F3-AE00-FED756B0D3B4")]
[assembly: TargetFramework(".NETFramework,Version=v4.0", FrameworkDisplayName = ".NET Framework 4")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
