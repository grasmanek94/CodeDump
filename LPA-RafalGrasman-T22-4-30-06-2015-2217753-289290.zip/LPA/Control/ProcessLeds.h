#ifndef PROCESSLEDS_HEADER
#define PROCESSLEDS_HEADER
void ProcessLeds(void);
#endif