#include "Config.h"

SConfig config;